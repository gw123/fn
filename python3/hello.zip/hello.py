def main():
    return "Hello, world!"
